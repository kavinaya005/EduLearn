# EduLearn React SPA (Demo)

This is a small single-file React SPA built for educational/demo use. It uses CDN builds of React, ReactDOM, React Router, and Tailwind via CDN. No build step or Node required.

Open `index.html` in your browser (double-click or use `File → Open`).

Demo login credentials:
- email: `student@example.com`
- password: `learn123`

Notes:
- This is for demo purposes only. It uses in-browser localStorage for a simple auth stub.
- For production, scaffold a proper React app (Vite/CRA), add a backend, and install Tailwind via PostCSS.
